declare module "*.svg"
